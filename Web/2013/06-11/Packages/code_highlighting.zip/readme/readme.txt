[center][img]http://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Cc-by_new_white.svg/25px-Cc-by_new_white.svg.png[/img] [img]http://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Cc-nc_white.svg/25px-Cc-nc_white.svg.png[/img] [img]http://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/Cc-nd_white.svg/25px-Cc-nd_white.svg.png[/img][hr][color=red][size=16pt][b]Code Highlighting[/b][/size][/color]
[color=blue][b][size=10pt]By Bugo[/size][/b][/color]

[color=green]This script highlights syntax in code examples on your forum.
It is very easy to use because it works automatically: finds blocks of code, detects a language, highlights it.
Supported languages: HTML/XML, Javascript, CSS, PHP, Ruby, Perl, Python, C++, C#, Java, SQL, Bash etc.[/color]

This uses a [url=http://softwaremaniacs.org/soft/highlight/en/]highlight.js[/url] script.

[b][size=11pt]LICENSE highlight.js[/size][/b]

Copyright (c) 2006, Ivan Sagalaev

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:[/center]
* Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
* Neither the name of highlight.js nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
[hr]This work is licensed under a [url=http://creativecommons.org/licenses/by-nc-nd/3.0/]CC BY-NC-ND[/url]