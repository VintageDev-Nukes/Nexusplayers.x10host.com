<?php

$txt['ch_title'] = 'Destaque da sintaxe';
$txt['ch_settings'] = 'configura&ccedil;&otilde;es do destaque';
$txt['ch_desc'] = 'Nesta &aacute;rea, voc&ecirc; pode activar/desactivar o realce, escolha etc tema preferido e o estilo.';
$txt['ch_enable'] = 'Activar destaque de sintaxe';
$txt['ch_style'] = 'Highlighting style';
$txt['ch_style_set'] = array(
	'arta' => 'Arta',
	'ascetic' => 'Ascetic',
	'brown_paper' => 'Brown Paper',
	'dark' => 'Dark',
	'default' => 'Default',
	'far' => 'FAR',
	'github' => 'GitHub',
	'googlecode' => 'Google Code',
	'hemisu-light' => 'Hemisu Light',
	'idea' => 'IDEA',
	'ir_black' => 'IR_Black',
	'magula' => 'Magula',
	'monokai' => 'Monokai',
	'pojoaque' => 'Pojoaque',
	'rainbow' => 'Rainbow',
	'school_book' => 'School Book',
	'solarized_dark' => 'Solarized Dark',
	'solarized_light' => 'Solarized Light',
	'sunburst' => 'Sunburst',
	'tomorrow' => 'Tomorrow',
	'tomorrow-night' => 'Tomorrow Night',
	'tomorrow-night-blue' => 'Tomorrow Night Blue',
	'tomorrow-night-bright' => 'Tomorrow Night Bright',
	'tomorrow-night-eighties' => 'Tomorrow Night Eighties',
	'vs' => 'Visual Studio',
	'xcode' => 'XCode',
	'zenburn' => 'Zenburn'
);
$txt['ch_tab'] = 'N&uacute;mero de caracteres entre as colunas de tab';
$txt['ch_fontsize'] = 'Tamanho da Fonte';
$txt['ch_example'] = 'Exemplo';

?>