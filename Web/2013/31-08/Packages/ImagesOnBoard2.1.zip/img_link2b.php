<?php
{
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
   require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
   die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

if (!array_key_exists('db_add_column', $smcFunc))
	db_extend('packages');

$img_link = array(
	'name' => 'img_link',
	'type' => 'tinytext',
	'null' => false,
	'default' => ''	
);

$smcFunc['db_add_column']('smf_ikillboards', $img_link);
	
if(SMF == 'SSI')
	echo 'Database updates complete!';

}
?>