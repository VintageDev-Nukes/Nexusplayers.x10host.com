<?php
{
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
   require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
   die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

global $db_prefix;

$request = db_query("
	SHOW COLUMNS FROM {$db_prefix}boards
	LIKE 'img_filename'", __FILE__, __LINE__);
	
$no_upgrade = mysql_num_rows($request) > 0;
mysql_free_result($request);

if (!$no_upgrade) 
	db_query("
		ALTER TABLE {$db_prefix}boards
		ADD COLUMN img_filename tinytext NOT NULL default ''
		", __FILE__,__LINE__);
	


$request1 = db_query("
	SHOW COLUMNS FROM {$db_prefix}boards
	LIKE 'img_link'", __FILE__, __LINE__);
	
$no_upgrade = mysql_num_rows($request1) > 0;
mysql_free_result($request1);

if (!$no_upgrade) db_query("
	ALTER TABLE {$db_prefix}boards
	ADD COLUMN img_link tinytext NOT NULL default ''
	", __FILE__,__LINE__);

}
?>