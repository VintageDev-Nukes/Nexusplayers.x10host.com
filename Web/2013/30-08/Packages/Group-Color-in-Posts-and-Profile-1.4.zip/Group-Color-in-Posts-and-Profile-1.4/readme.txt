[center][b][color=red]Group Color in Posts and Profile[/color][/b]
Version: 1.4
For SMF 2.0.1
By AJ Collins
aj@gzwn.net[/center]

This mod will add a group's color to the group name in posts and on profiles. You can change the color for each group in the membergroups section of the admin panel.

[b]How it'll look[/b]
In a post:
[img]http://gzwn.net/pics/SMF mods/groupcolor/inpost.png[/img]
In a profile:
[img]http://gzwn.net/pics/SMF mods/groupcolor/inprofile.png[/img]

[b]Install[/b]
For most themes, install should go fine if the theme doesn't have a custom Profile.template and a Display.template. If your theme does contain custom versions of these files,
either try SMF's "Install in Other Themes" option or look at the modification file and try to edit the files yourself.

[b]History[/b]
1.4 - Official support for 2.0.1 and fixed "group_color" error.
1.3 - Added support for RC5.
1.2 - Fixed SMF trying to get a group color for messages posted by guests which caused an error in the error log.
1.1 - Added color support for posting groups.
1.0 - Initial Release.