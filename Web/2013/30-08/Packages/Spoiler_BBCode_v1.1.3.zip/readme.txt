[center][hr][color=red][size=16pt][b]Spoiler BBCODE v1.1.3[/b][/size][/color]
[hr][url=http://forum.himsi-ubm.com/index.php/topic,209.0.html][b]Demo[/b][/url][hr][/center]

[color=orange][b]Compatibility[/b][/color]
For SMF 1.1.x
For SMF 2.0 RC2
For SMF 2.0 RC3

[color=orange][b]Description[/b][/color]
This mod adds a new bbcode tag that'll hide what you wrap with it. It works with text and images. Clicking on the spoiler link, reveals the block. You can optionally add a text to the link too, ie: [spoiler=My Title]Spoiler goes here[/spoiler].

[color=orange][b]Changelog[/b][/color]
Quote And Code Tag FIX

[color=orange][b]Screnshot[/b][/color]
SMF : 1.1.11
[img width=800 height=488]http://img192.imageshack.us/img192/6950/spoilerz.png[/img]

SMF : 2.0 RC3
[img width=800 height=601]http://img257.imageshack.us/img257/1017/ssspoiler2.png[/img]

[color=orange][b]Donation[/b][/color]
[table]
[tr][td]
[url=https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=Y9RYC29FXQDME&lc=ID&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted][img]https://www.paypal.com/en_US/i/btn/btn_donateCC_LG.gif[/img][/url]
[/td][td]
If you like my modification packages, please donate to support their continued development.
Any amount will be greatly appreciated. Thank you!
[/td][/tr]
[/table]